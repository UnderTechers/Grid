#include<bits/stdc++.h>
using namespace std;
int main(){
    cout << "test line 1";
    cout << "test deleted line 2";
    cout << "test line 3";
    cout << "test changed line 4";
}